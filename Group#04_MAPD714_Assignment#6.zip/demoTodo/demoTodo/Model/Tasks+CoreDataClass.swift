//
//  Tasks+CoreDataClass.swift
//  demoTodo
//
//  Created by Apeksha Parmar on 2022-12-07.
//
//

import Foundation
import CoreData

@objc(Tasks)
public class Tasks: NSManagedObject {

}
