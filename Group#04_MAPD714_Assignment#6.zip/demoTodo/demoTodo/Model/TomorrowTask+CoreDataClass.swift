//
//  TomorrowTask+CoreDataClass.swift
//  demoTodo
//
//  Created by Apeksha Parmar on 2022-12-07.
//
//

import Foundation
import CoreData

@objc(TomorrowTask)
public class TomorrowTask: NSManagedObject {

}
