//
//  CompletedTask+CoreDataClass.swift
//  demoTodo
//
//  Created by Apeksha Parmar on 2022-12-07.
//
//

import Foundation
import CoreData

@objc(CompletedTask)
public class CompletedTask: NSManagedObject {

}
